import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Header } from './components/header/header';
import { Sidebar } from "./components/sidebar/sidebar";
import { Products } from "./components/products/products";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [Header, Sidebar, Products],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  isDarkMode = false;
  searchValue:string = '';
  categoryValue:string='';
   onSearchChanged(value: string) {
    this.searchValue = value;
  }
  selectedCategory(category: string){
    this.categoryValue=category;
  }
    darkMode() {
    this.isDarkMode = !this.isDarkMode;
    console.log(this.isDarkMode);
  }
  protected readonly title = signal('GPITask');
}
