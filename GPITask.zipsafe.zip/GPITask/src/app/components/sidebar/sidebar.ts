import { Component, EventEmitter, Output } from '@angular/core';
import { ProductService } from '../../services/product-service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.css'
})
export class Sidebar {
  categoryProducts: any[]= [];
  constructor (private productsServiceCategory: ProductService){}
 @Output() categorySelected = new EventEmitter<string>();
  ngOnInit():void{
    this.productsServiceCategory.getProductCategory().subscribe((cat)=>{
      this.categoryProducts = cat;
      console.log(this.categoryProducts);
  });
}
  onCategoryClick(category: string) {
    this.categorySelected.emit(category); 
  }
}
