import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { ProductService } from '../../services/product-service';
import { Product } from '../../interface/product';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [FormsModule, CommonModule],
  templateUrl: './products.html',
  styleUrls: ['./products.css']
})
export class Products implements OnInit, OnChanges {
  ProductsData: Product[] = [];
  selectedProduct: Product | null = null;
  @Input() search: string = '';
  @Input() category: string = '';
  filteredProducts: Product[] = [];

  constructor(private productsService: ProductService) {}

  ngOnInit(): void {
    this.productsService.getAllProducts().subscribe((data: Product[]) => {
      this.ProductsData = data;
      this.filterProducts(); 
    });
  }

  ngOnChanges() {
    if(this.ProductsData.length) {
      this.filterProducts();
    }
  }

  filterProducts() {
    this.filteredProducts = this.ProductsData.filter(p => {
      const matchesSearch = p.title.toLowerCase().includes(this.search.toLowerCase());
      const matchesCategory = this.category ? p.category === this.category : true;
      return matchesSearch && matchesCategory;
    });
  }

  openProductDetails(productId: number) {
    this.productsService.getProductById(productId).subscribe(product => {
      this.selectedProduct = product; 
    });
  }
}
