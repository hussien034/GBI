import { Component, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [],
  templateUrl: './header.html',
  styleUrl: './header.css'
})
export class Header {
@Output() searchChanged = new EventEmitter<string>();
@Output() toggle = new EventEmitter<void>();
onSearch(event: any) {
  this.searchChanged.emit(event.target.value);
}
}
